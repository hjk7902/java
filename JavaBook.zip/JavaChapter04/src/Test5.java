
public class Test5 {
    public static void main(String[] args) {
        int sum = 0;
        int number = 0;

        while (sum <= 1000) {
            if (number % 2 == 0) {
                sum += number;
            }
            number++;
        }

        System.out.println("0부터 짝수의 합이 1000보다 큰 가장 작은 정수: " + (number - 1));
    }
}
