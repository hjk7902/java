package interface_;

public interface IToDo4 {
	void m4();
}