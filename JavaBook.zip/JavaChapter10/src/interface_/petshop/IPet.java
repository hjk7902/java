package interface_.petshop;

public interface IPet {
	void play(); // public abstract void play();
}