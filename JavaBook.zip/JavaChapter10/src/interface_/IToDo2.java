package interface_;

public interface IToDo2 {
	void m2();
}

