package test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentManager {
    private Map<String, Student> studentMap = new HashMap<>();

    // 학생 추가
    public void addStudent(String name, int score) {
        if (studentMap.containsKey(name)) {
            System.out.println("이미 등록된 학생입니다: " + name);
            return;
        }
        studentMap.put(name, new Student(name, score));
    }

    // 성적 기준 내림차순 출력
    public void printSortedStudents() {
        List<Student> studentList = new ArrayList<>(studentMap.values());
        studentList.sort((a, b) -> b.getScore() - a.getScore());
        System.out.println("성적 내림차순 정렬 결과:");
        for (Student s : studentList) {
            System.out.println(s);
        }
    }

    // 이름으로 학생 검색
    public void searchStudent(String name) {
        Student s = studentMap.get(name);
        if (s != null) {
            System.out.println(name + "의 성적은: " + s.getScore());
        } else {
            System.out.println("해당 이름의 학생이 존재하지 않습니다.");
        }
    }

    // 평균 성적 계산
    public void printAverageScore() {
        if (studentMap.isEmpty()) {
            System.out.println("등록된 학생이 없습니다.");
            return;
        }
        int total = 0;
        for (Student s : studentMap.values()) {
            total += s.getScore();
        }
        double avg = (double) total / studentMap.size();
        System.out.printf("전체 평균 성적: %.2f\n", avg);
    }
}