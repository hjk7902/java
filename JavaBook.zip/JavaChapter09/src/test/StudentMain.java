package test;

import java.util.Scanner;

public class StudentMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManager manager = new StudentManager();

        System.out.print("등록할 학생 수를 입력하세요: ");
        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n; i++) {
            System.out.printf("학생 %d 이름: ", i + 1);
            String name = scanner.nextLine();
            System.out.printf("학생 %d 성적: ", i + 1);
            int score = Integer.parseInt(scanner.nextLine());

            manager.addStudent(name, score);
        }

        System.out.println();
        manager.printSortedStudents();

        System.out.println();
        System.out.print("성적을 조회할 학생 이름을 입력하세요: ");
        String searchName = scanner.nextLine();
        manager.searchStudent(searchName);

        System.out.println();
        manager.printAverageScore();

        scanner.close();
    }
}