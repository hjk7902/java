package enums;

public enum Coin2 {
	PENNY { 
		int getCent() { 
			return 1;
		} 
	},
	NICKEL { 
		int getCent() { 
			return 5;
		}
	},
	DIME { 
		int getCent() { 
			return 10;
		}
	},
	QUARTER { 
		int getCent() {
			return 25;
		}
	};

	abstract int getCent();
}
