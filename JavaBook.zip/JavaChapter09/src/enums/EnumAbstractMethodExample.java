package enums;

public class EnumAbstractMethodExample {
	public static void main(String[] args) {
		for(Coin2 coin : Coin2.values()) {
			System.out.println(coin + "의 값은 " + coin.getCent());
		}
	}
}
