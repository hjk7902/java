package enums;

public class EnumMethodExample {
	public static void main(String[] args) {
		for(Coin coin : Coin.values()) {
			System.out.println(coin + "의 값은 " + coin.getCent());
		}
	}
}
