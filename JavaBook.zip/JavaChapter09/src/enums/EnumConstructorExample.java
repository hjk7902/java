package enums;

public class EnumConstructorExample {
	public static void main(String[] args) {
		for(Coin3 coin : Coin3.values()) {
			System.out.println(coin + "의 값은 " + coin.getCent());
		}
	}
}