package enums;

public class EnumSuitExample {
	private static final Suit[] CARD_SUIT = { 
		Suit.CLUBS,
		Suit.DIAMONDS,
		Suit.HEARTS,
		Suit.SPADES
	};

	public static void main(String[] args) {
		for(Suit suit : CARD_SUIT) {
			System.out.println(suit);
		}
		
		System.out.println();
		Suit suit = CARD_SUIT[0];
		if(suit == Suit.CLUBS) {
			System.out.println("clubs");
		}else if(suit == Suit.DIAMONDS) {
			System.out.println("diamonds");
		}else if(suit == Suit.HEARTS) {
			System.out.println("hearts");
		}else if(suit == Suit.SPADES) {
			System.out.println("spades");
		}else {
			throw new NullPointerException("Null Suit");
		}
	}
}
