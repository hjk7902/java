package enums;

public enum Coin3 {
	PENNY(1),
	NICKEL(5),
	DIME(10),
	QUARTER(25);

	private final int cent;

	Coin3(int cent) {
		this.cent = cent;
	}

	public int getCent() {
		return cent;
	}
}
