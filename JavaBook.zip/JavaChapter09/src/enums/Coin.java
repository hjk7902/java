package enums;

public enum Coin {
	PENNY,
	NICKEL,
	DIME,
	QUARTER;

	public int getCent() {
		switch(this) {
			case PENNY: return 1;
			case NICKEL: return 5;
			case DIME: return 10;
			case QUARTER: return 25;
			default: return 0;
		}
	}
}