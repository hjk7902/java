package enums;

import java.util.TreeSet;

public class EnumSuitSortExample {
	public static void main(String[] args) {
		Suit clubs = Suit.CLUBS;
		Suit diamonds = Suit.DIAMONDS;
		Suit hearts = Suit.HEARTS;
		Suit spades = Suit.SPADES;

		TreeSet<Suit> suits = new TreeSet<>();
		suits.add(spades);
		suits.add(hearts);
		suits.add(diamonds);
		suits.add(clubs);

		for(Suit suit : suits) {
			System.out.println(suit);
		}
	}
}
