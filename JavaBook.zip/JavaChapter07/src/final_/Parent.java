package final_;

//public final class Parent{
public class Parent{
	public final void method() {
		System.out.println("Parent - method()");
	}
}