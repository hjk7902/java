package final_;

public class Child extends Parent { 
//	public void method() { //Error
//		System.out.println("Child - method()");
//	}
}