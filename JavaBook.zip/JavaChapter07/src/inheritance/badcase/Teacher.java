package inheritance.badcase;

public class Teacher {
	public String name;
	public int age;
	public String subject;

	public String getDetails() {
		return "이름: " + name + "\t나이 : " + age + "\t과목: " + subject;
	}
}
