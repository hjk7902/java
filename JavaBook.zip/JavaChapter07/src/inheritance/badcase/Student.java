package inheritance.badcase;

public class Student {
	public String name;
	public int age;
	public String major;

	public String getDetails() {
		return "이름: " + name + "\t나이 : " + age + "\t전공: " + major;
	}
}
