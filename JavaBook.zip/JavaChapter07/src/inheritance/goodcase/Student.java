package inheritance.goodcase;

public class Student extends Person{
	public String major;
}
