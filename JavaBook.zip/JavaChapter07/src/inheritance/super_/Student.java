package inheritance.super_;

public class Student extends Person{

	private String major;
	
	public Student(String name, int age, String major) {
		super(name, age);
		this.major = major;
	}

	public String getDetails() {
		return super.getDetails() + "\t전공: " + major;
	}
}