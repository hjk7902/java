package com.example.calculator.internal;

public class InternalCalculator {
    public int add(int a, int b) {
        return a + b;
    }
}
