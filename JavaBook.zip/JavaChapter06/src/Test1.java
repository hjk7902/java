public class Test1{
	Integer i;
	int x;
	public Test1(int y) {
		x = i+y;
		System.out.println(x);
	}
	public static void main(String[] args) {
		new Test1(4);
	}
}