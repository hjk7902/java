public class EmpVO { 
	// 필드 선언
	// setter/getter
}