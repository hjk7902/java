package inheritance.goodcase;

public class Teacher extends Person{
	public String subject;
}
