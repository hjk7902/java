package inheritance.goodcase;

public class Person {
	public String name;
	public int age;
	public String getDetails() {
		return "이름: " + name + "\t나이: " + age;
	}
}
