package inheritance.goodcase;

public class Employee extends Person{
	public String department;
}
