package inheritance.overriding;

public class Person {
	protected String name;
	protected int age;

	public String getDetails() {
		return "이름: " + name + "\t나이: " + age;
	}
}