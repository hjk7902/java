package inheritance.badcase;

public class Student {
	public String name;
	public int age;
	public String studentId;

	public String getDetails() {
		return "이름: " + name + "\t나이 : " + age + "\t학번: " + studentId;
	}
}
