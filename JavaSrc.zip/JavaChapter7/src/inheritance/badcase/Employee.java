package inheritance.badcase;

public class Employee {
	public String name;
	public int age;
	public String department;

	public String getDetails() {
		return "이름: " + name + "\t나이 : " + age + "\t부서: " + department;
	}
}
