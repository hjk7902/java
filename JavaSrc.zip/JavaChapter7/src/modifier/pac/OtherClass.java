package modifier.pac;

public class OtherClass {
	public void doSomething() {
		SomeClass s = new SomeClass();
		s.print();
//		System.out.println(s.num4); //Error
	}
}
