package modifier.pac;

public class SomeClass {

	private			int num4 = 40;
	
	public void print() {
		System.out.println("Super num4 = " + num4);
	}
}