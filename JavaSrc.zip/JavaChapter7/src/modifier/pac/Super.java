package modifier.pac;

public class Super {
	public			int num1 = 10;
	protected		int num2 = 20;
	/*friendly*/	int num3 = 30;
	private			int num4 = 40;
	
	public int getNum4() {
		return num4;
	}
}