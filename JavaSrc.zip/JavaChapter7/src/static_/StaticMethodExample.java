package static_;

public class StaticMethodExample {
	public static void main(String[] args) {
		System.out.println("Count.doIt() : " + Count.doIt());
		System.out.println("Count.doIt() : " + Count.doIt());
		System.out.println("Count.doIt() : " + Count.doIt());
	}
}