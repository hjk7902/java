package annotation;

//애노테이션 사용
public class MyClass {
	@MyAnnotation(value = "Hello")
	public void myMethod() {
		// 메서드 내용
	}
}
