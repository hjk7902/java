package interface_.petshop;

public abstract class Fish {
	public abstract void swim();
}