package interface_.petshop;

public class Tiger extends Animal{

	public void eat() {
		System.out.println("호랑이는 고기를 먹습니다.");
	}
}