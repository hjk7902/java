package interface_;

public interface IToDo1 {
	void m1();
}

