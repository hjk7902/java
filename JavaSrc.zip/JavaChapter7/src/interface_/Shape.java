package interface_;

public interface Shape {
	public abstract double getArea();
}