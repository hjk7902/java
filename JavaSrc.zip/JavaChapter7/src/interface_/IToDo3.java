package interface_;

public interface IToDo3 extends IToDo1, IToDo2 {
	void m3();
}

