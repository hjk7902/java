/**
 * HelloWorld 클래스
 */
public class HelloWorld {

	/**
	 * 메인 메서드
	 * @param args
	 */
	public static void main(String[] args) {
		// 콘솔에 정보를 출력합니다.
		System.out.println("안녕 자바!");
	}

}
