
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");
		double a = 0.2;
		double b = 0.1;
		double c = a+b;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(Double.PRECISION);
		System.out.println(Float.PRECISION);
	}

}
