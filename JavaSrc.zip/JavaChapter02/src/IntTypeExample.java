
public class IntTypeExample {
	public static void main(String[] args) {
		byte a = 127;
		short b = 32767;
		int c = 2147483647;
		long d = 2147483648L;
		System.out.printf("%d,%d,%d,%d", a,b,c,d); //형식을 지정해서 출력
		
	}
}
