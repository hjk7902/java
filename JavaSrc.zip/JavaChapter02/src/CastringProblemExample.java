
public class CastringProblemExample {

	public static void main(String[] args) {
		int a = 1234567890;
		float b = a;
		System.out.println(b);
		
		double c = 3.6;
		int d = (int)c;
		System.out.println(d);
		
		int e = 1522;
		byte f = (byte)e;
		System.out.println(f);
	}

}
