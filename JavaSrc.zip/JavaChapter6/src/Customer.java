public class Customer {
	String name;
	char gender;
	String email;
	int birthYear;
	
	public Customer(String name, char gender, String email, int birthYear) {
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.birthYear = birthYear;
	}
	
	public Customer() {
	}
}

