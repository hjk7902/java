@FunctionalInterface
public interface MyFunction {
	int myMethod(String s);
}
