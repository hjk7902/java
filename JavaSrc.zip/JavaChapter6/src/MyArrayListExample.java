import java.util.ArrayList;

public class MyArrayListExample {
    public static void main(String[] args) {
        ArrayList<String> myList = new ArrayList<>();
        System.out.println(myList.size());
        // myList와 같은 ArrayList 관련 작업 수행
    }
}

//public class MyArrayListExample {
//    public static void main(String[] args) {
//        java.util.ArrayList<String> myList = new java.util.ArrayList<>();
//        // myList와 같은 ArrayList 관련 작업 수행
//    }
//}
