import static java.lang.Math.sqrt;

public class ImportStaticExample {
    public static void main(String[] args) {
        double result = sqrt(16.0);
        System.out.println("Square root of 16 is: " + result);
    }
}
