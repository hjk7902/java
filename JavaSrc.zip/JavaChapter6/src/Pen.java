public class Pen {
	String color;
	int price;
	
	public Pen() {
		this("black", 500);
	}

	public Pen(String init_color, int init_price) {
		color = init_color;
		price = init_price;
		System.out.println("생성자를 이용하여 color를 초기화");
	}
	
	public void write(int count) {
		for(int i=0; i<count; i++) {
			System.out.println(color + "색으로 글을 씁니다.");
		}
		System.out.println("가격: " + price);
	}
}