
public class MaskingEXample {

	public static void main(String[] args) {
		int originalValue = 0xabcd1234;
		int extractedByte = originalValue & 0x000000FF;
		System.out.println(Integer.toHexString(originalValue));
		System.out.println(Integer.toHexString(extractedByte));
		System.out.println(extractedByte);
	}

}
