
public class AssignmentExample {

	public static void main(String[] args) {
		int a=5, b=5;
		a += 3; // a=a+3
		System.out.println(a);
		b =+ 3;
		System.out.println(b);
	}

}
