public class ArithmeticOperatorsExample {
    public static void main(String[] args) {
        // 덧셈
        int sum = 5 + 3;
        System.out.println("덧셈: " + sum); // 출력: 8

        // 뺄셈
        int difference = 7 - 2;
        System.out.println("뺄셈: " + difference); // 출력: 5

        // 곱셈
        int product = 4 * 6;
        System.out.println("곱셈: " + product); // 출력: 24

        // 나눗셈
        double divide = 10.0 / 3.0;
        System.out.println("나눗셈: " + divide); // 출력: 3.3333333333333335

        // 나머지
        int remainder = 10 % 3;
        System.out.println("나머지: " + remainder); // 출력: 1
        
        // 정수와 정수의 나눗셈은 몫을 계산함
        double quotient = 10 / 3;
        System.out.println("나눗셈: " + quotient); // 출력: 3.0
    }
}
