public class Test6 {
	public static void main(String[] args) {
		String str = "420";
		str += 42;
		System.out.print(str);
	}
}