public class MixedExample {
    public static void main(String[] args) {
        int x = 3;
        int y = ++x + x--;  // x = 4 + 4
        System.out.println("y: " + y);
        System.out.println("x: " + x);
        
        int a = 3;
        int b = a++ + ++a;  // b = 3 + 5
        System.out.println("b: " + b);
        System.out.println("a: " + a);
    }
}
