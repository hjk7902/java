public class BitMaskingExample {
	public static void main(String[] args) {
		int pixel = 0xFFF07896; // Alpha:FF, Red:F0, Green:78, Blue:96
		int blue = pixel & 0x000000FF; // Blue값만 빼고 싶을 경우
		System.out.printf("16진수 %x, 10진수 %d \n", blue, blue);
		
		int red = pixel & 0x00FF0000;
		red = red >> 16; // Red 성분은 비트 이동 연산자를 이용해야 함
		System.out.printf("16진수 %x, 10진수 %d \n", red, red);
	}
}	