
public class IncrementExample2 {

	public static void main(String[] args) {
		int i = 1;
		int j = i++;
		System.out.println(j);
		
		int x = 1;
		int y = ++x;
		System.out.println(y);
	}

}
