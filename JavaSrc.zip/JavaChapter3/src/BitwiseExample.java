
public class BitwiseExample {

	public static void main(String[] args) {
		byte a = 5;
		byte b = 3;
		System.out.println(a & b);
		System.out.println(a | b);
		System.out.println(a ^ b);  // 2^3 -> 10 ^ 11 -> 01
		System.out.println(2 ^ 3);
	}

}
