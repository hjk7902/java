public class StringComparisonExample {
    public static void main(String[] args) {
        String str1 = new String("Hello");
        String str2 = new String("Hello");
        
        // == 연산자를 사용하여 참조 값 비교
        System.out.print("Using == operator: ");
        System.out.println(str1 == str2); // false (참조 값이 다름)

        // != 연산자를 사용하여 참조 값 비교
        System.out.print("Using != operator: ");
        System.out.println(str1 != str2); // true (참조 값이 다름)
    }
}

