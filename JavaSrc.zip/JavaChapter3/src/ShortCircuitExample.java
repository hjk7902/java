public class ShortCircuitExample {
	public static void main (String[] args) {
		int x=10, y=20;
		System.out.println((x != 10) & (++y == 21)); // false
		System.out.println("y: " + y); // y: 21

		System.out.println((x == 10) | (++y == 21)); // true
		System.out.println("y: " + y); // y: 22

		int a=10, b=20;
		System.out.println((a != 10) && (++b == 21)); // false
		System.out.println("b: " + b); // b: 20

		System.out.println((a == 10) || (++b == 21)); // false
		System.out.println("b: " + b); // b: 20
	}
}
