public class BitShiftExample {
	static void printBinStr(int i) {
		String binStr = Integer.toBinaryString(i);
		System.out.printf("[%32s], %d\n", binStr, i);
	}
	public static void main(String[] args) {
		int x = 192;
		printBinStr(x); // [                        11000000], 192
		
		int a = x << 3;
		printBinStr(a); // [                     11000000000], 1536

		int b = x >> 3;
		printBinStr(b); // [                           11000], 24

		int y = -192;
		printBinStr(y); // [11111111111111111111111101000000], -192
		
		int c = y << 3;
		printBinStr(c); // [11111111111111111111101000000000], -1536
		
		int d = y >> 3;
		printBinStr(d); // [11111111111111111111111111101000], -24
		
		int e = y >>> 3;
		printBinStr(e); // [   11111111111111111111111101000], 536870888

		int f = y >>> 35;
		printBinStr(f); // [   11111111111111111111111101000], 536870888
	}
}

