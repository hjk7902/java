
public class Test7 {
	public static void main(String[] args) {
		int num = 1;
		System.out.println(num--);
		System.out.println(--num);
		System.out.println(num -= 1);
		System.out.println(num = num - 1);
	}
}
