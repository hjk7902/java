
public class DivModExample {

	public static void main(String[] args) {
		int number = 45;
		int tensDigit = number / 10;
		int unitsDigit = number % 10;
		System.out.println(tensDigit + unitsDigit);
	}

}
