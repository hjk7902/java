
public class Test8 {
	public static void main(String[] args) {
		byte x = 10;
		System.out.println(Integer.toBinaryString(~x));
	}
}
