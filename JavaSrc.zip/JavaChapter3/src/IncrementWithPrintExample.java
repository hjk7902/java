
public class IncrementWithPrintExample {

	public static void main(String[] args) {
		int a = 5;
		++a;
		System.out.println("a: " + a);
		
		int b = 5;
		System.out.println("++b: " + b++);
		System.out.println(b);
		
		int c = 5;
		System.out.println("c++: " + ++c);
	}

}
