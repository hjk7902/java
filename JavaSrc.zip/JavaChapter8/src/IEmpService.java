public interface IEmpService {
	void insert(EmpVO vo);
}