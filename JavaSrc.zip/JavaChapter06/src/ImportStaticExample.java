//import static java.lang.Math.sqrt;

import java.util.Date;

public class ImportStaticExample {

	public static void main(String[] args) {
		Date now = new Date();
		double result = Math.sqrt(64);
		System.out.println(result);
	}

}
