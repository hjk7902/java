package com.example.otherpackage;

import com.example.mypackage.MyClass;

public class AnotherClass {

	public static void main(String[] args) {
		MyClass myObject = new MyClass();
//		myObject.packagePrivateMethod();
	}

}
