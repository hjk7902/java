package com.example.mypackage;

public class MyClass {
	void packagePrivateMethod() {
		System.out.println("MyClass.method");
	}
}
