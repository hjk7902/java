public class ForExample {
	public static void main(String[] args) {
		int sum = 0;
		for (int i=0; i<=10; i++) {
			sum = sum + i;
		}
//		int i=0;
//		for ( ; i<=10; ) {
//			sum = sum + i;
//			i++;
//		}
		System.out.println("합계: " + sum); // 55
	}
}
