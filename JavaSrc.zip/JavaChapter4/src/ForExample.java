
public class ForExample {

	public static void main(String[] args) {
		int sum = 0;
		int i=0;
		for(; i<=10; ) {
			sum = sum + i;
			i++;
		}
//		for(;;) {}
		System.out.println(sum);
//		for(;;) { }
	}

}
