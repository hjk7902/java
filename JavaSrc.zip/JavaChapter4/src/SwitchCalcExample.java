import java.util.Scanner;

public class SwitchCalcExample {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("수식을 입력하세요(예: 5 x 8) ");
		int num1 = scanner.nextInt();
		String op = scanner.next();
		int num2 = scanner.nextInt();

		switch(op.charAt(0)) {
		case '+' : 
			System.out.println(num1 + num2);
			break;
		case 'x' :
			System.out.println(num1 * num2);
			break;
		case '/' : 
			System.out.println(num1 / num2);
			break;
		case '-' :
			System.out.println(num1 - num2);
			break;
		default :
			System.out.println("잘못된 연산식입니다.");
		} //end switch
		
		scanner.close();
	} //end main
}
