
public class Test7 {
	public static void main(String[] args) {
		int dan = 5;
		
		for(int i=0; i<dan; i++) {
			for(int j=0; j<dan-i-1; j++) {
				System.out.print(" ");
			}
			for(int j=0; j<i+1; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		String star = "";
		for(int i=0; i<dan; i++) {
			star = star+"*";
			System.out.printf("%5s\n", star);
		}
	}
}
