public class SwitchExpressionExample {
	public static void main(String[] args) {
		int a = (int)(Math.random()*10);
		char b = switch(a) {
			case 9, 8 -> 'A';
			case 7, 6, 5 -> {
				System.out.println("7, 6, 5 입니다.");
				yield 'B';
			}
			default -> 'C';
		};
		System.out.println(b);
	}
}

//public class SwitchExpressionExample {
//	public static void main(String[] args) {
//		String day = "Monday";
//		String typeOfDay = null;
//
//		switch (day) {
//		    case "Monday":
//		        typeOfDay = "Start of work week";
//		        break;
//		    case "Tuesday":
//		    case "Wednesday":
//		    case "Thursday":
//		        typeOfDay = "Midweek";
//		        break;
//		    case "Friday":
//		        typeOfDay = "End of work week";
//		        break;
//		    case "Saturday":
//		    case "Sunday":
//		        typeOfDay = "Weekend";
//		        break;
//		    default:
//		        typeOfDay = "Invalid Day";
//		}
//		String typeOfDay = switch (day) {
//		    case "Monday" -> "Start of work week";
//		    case "Tuesday", "Wednesday", "Thursday" -> "Midweek";
//		    case "Friday" -> "End of work week";
//		    case "Saturday", "Sunday" -> "Weekend";
//		    default -> "Invalid Day";
//		};
//
//		System.out.println(typeOfDay);
//	}
//}
