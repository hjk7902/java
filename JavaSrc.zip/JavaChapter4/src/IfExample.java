import java.util.Scanner;

public class IfExample {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("점수를 입력하세요: ");
		int testscore = scanner.nextInt();

		System.out.println("점수 : " + testscore );
		if (testscore  >= 60) System.out.println("합격");
		scanner.close();
	}
}
