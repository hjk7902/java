
public class OperationCastingExample {

	public static void main(String[] args) {
		byte a=10, b=20;
		byte c = (byte)(a+b);
		System.out.println(c);
		byte d = 10 + 20;
		System.out.println(d);
		short e = 100 + 200;
		System.out.println(e);
		System.out.println(5/2);
		System.out.println(5/2.);
	}

}
