
public class FloatNotationExample {

	public static void main(String[] args) {
		double num1 = 123.456;
		double num2 = 1.23456e2;
		System.out.println(num1);
		System.out.println(num2);
	}

}
