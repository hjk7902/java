
public class MemberVariableExample {

	int a; // instance variable
	static int b; // class varible, static variable
	public static void main(String[] args) {
		MemberVariableExample me = new MemberVariableExample(); // 객체
		System.out.println(me.a);
		System.out.println(b);

	}

}
