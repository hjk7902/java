
public class StringPlusExample {

	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "World";
		int a1=3, a2=5;
		System.out.println(s1+s2);
		System.out.println(s1+a1+a2);
		System.out.println(a1+a2+s1);
		System.out.println(s1 + (a1+a2));
	}

}
