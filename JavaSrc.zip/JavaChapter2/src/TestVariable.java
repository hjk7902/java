
public class TestVariable {
	public static void main(String[] args) {
		byte a = 10;
		short b = 10000;
		int c = 20000000;
		long d = 999999999999999L;
		float e = 3.5F;
		double f = 3.5;
		char g = 'A';
		boolean h = true;
		String i = "Hello Java";
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);	
		System.out.println(i);
	}
}
