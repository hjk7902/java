
public class BooleanTypeExample {

	public static void main(String[] args) {
		boolean b1 = false;
//		boolean b2 = False; 
//		boolean b3 = "false"; //String
//		boolean b4 = 1; // int
		System.out.println(b1);
	}

}
