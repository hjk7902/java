
public class ApproximateExample {

	public static void main(String[] args) {
		float num1 = 0.12345678901234567890F;
		float num2 = 123.12345678901234567890F;
		double num3 = 0.12345678901234567890;
		double num4 = 123.12345678901234567890;
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
	}

}
