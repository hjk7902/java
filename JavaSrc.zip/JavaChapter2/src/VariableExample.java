
public class VariableExample {

	public static void main(String[] args) {
		int numberOne = 10;
		int numberTwo = 20;
		int result = numberOne + numberTwo;
		System.out.println(result);
	}

}
