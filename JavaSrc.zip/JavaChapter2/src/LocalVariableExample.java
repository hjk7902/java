
public class LocalVariableExample {

	public static void main(String[] args) {
		int a = 100;
		System.out.println(a);
	}

}
