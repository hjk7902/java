
public class FloatTypeExample {

	public static void main(String[] args) {
		float num1 = 1.1F;
		double num2 = 1.1;
		System.out.println(num1);
		System.out.println(num2);
	}

}
