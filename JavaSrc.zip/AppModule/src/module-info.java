module AppModule {
	requires CalculatorModule;
}
