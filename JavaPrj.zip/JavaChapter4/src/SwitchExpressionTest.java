import java.util.Scanner;

public class SwitchExpressionTest {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("점수를 입력하세요:");
		int score = scanner.nextInt();
		char grade;
		if(score > 100) {
			System.out.println("잘못된 입력입니다.");
		}else {
			// 아래 구문을 switch~expression 식으로 바꾸세요.
			grade = switch(score/10) {
			case 10, 9 -> 'A';
			case 8 -> 'B';
			case 7 -> 'C';
			case 6 -> 'D';
			default -> 'F';
			};
//			if(score >= 90) {
//				grade = 'A';
//			}else if(score >= 80) {
//				grade = 'B';
//			}else if(score >= 70) {
//				grade = 'C';
//			}else if(score >= 60) {
//				grade = 'D';
//			}else {
//				grade = 'F';
//			}
			System.out.printf("점수 %d의 등급은 %c\n", score, grade);
			if(score >= 60) {
				System.out.println("합격");
			}else {
				System.out.println("불합격");
			}
		}
		scanner.close();
	}
}
