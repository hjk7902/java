public class Exam1 {
	public static void main(String[] args) {
		int age = 25;
		System.out.println("홍길동님의 나이는 " + age + "입니다.");
		System.out.println("감사합니다.");
	}
}
