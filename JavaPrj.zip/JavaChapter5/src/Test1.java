
public class Test1 {
	public static void main(String[] args) {
		String[] elements = { "for", "tea", "too" };
		String result = (elements.length > 0) ? elements[0] : null;
		System.out.println(result);
	}
}
