
public class ArithmeticOperatorsExample {

	public static void main(String[] args) {
		System.out.println(5+3);
		
		int difference = 7-2;
		System.out.println(difference);
		
		int product = 4 * 6;
		System.out.println(product);
		
		double divide = 10.0 / 3.0;
		System.out.println(divide);
		
		int remainder = 10 % 3;
		System.out.println(remainder);
		
		double quotient = 10 / 3;
		System.out.println(quotient);
		
		System.out.println(5/2.);
	}

}
