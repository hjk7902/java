import static java.lang.Math.sqrt;

public class ImportStaticExample {

	public static void main(String[] args) {
		double result = sqrt(64);
		System.out.println(result);
	}

}
