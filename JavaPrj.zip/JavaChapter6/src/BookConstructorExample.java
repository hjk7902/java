
public class BookConstructorExample {

	public static void main(String[] args) {
		Book b1 = new Book();
		Book b2 = new Book("자바", "허진경");
		System.out.println(b1);
		System.out.println(b2);
	}

}
